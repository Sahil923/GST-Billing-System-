<?php

require_once 'idiorm.php';

ORM::configure('sqlite:include/invoice.db');
?>